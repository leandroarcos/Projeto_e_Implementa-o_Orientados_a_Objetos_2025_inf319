Author: Luiz Eduardo Busato
License: see file LICENSE.txt

stackQueueDelegation is a very simple  program that illustrates how to
implement  a stack  using delegation  from an  already existent  queue
implementation.    In   conjunction   with  its   companion   project,
stackQueueInheritance,  it is  used to  show the  trade-off between  a
design  that allows  reuse  without compromising  encapsulation and  a
design   that    clearly   compromises   encapsulation    and,   thus,
maintainabilty.

Origin: a clone of inf319git/queuedStack [2023/09].

