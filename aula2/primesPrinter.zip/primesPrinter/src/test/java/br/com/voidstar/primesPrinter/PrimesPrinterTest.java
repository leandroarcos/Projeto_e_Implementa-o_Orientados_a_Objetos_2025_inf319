package br.com.voidstar.primesPrinter;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class PrimesPrinterTest 
{

    @Test
    public void PrimesPrinterTest() {
	// I will not bother with the creation of
	// a work around to test the main program,
	// just compile and run it outside
	// the testing environment
	assertTrue(true);
}
}
