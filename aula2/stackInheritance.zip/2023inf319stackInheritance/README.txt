Author: Luiz Eduardo Busato
License: see file LICENSE.txt

stackQueueInheritance is a very simple program that illustrates how to
implement a  stack using  inheritance from  an already  existent queue
implementation.    In   conjunction   with  its   companion   project,
stackQueueDelegation,  it is  used  to show  the  trade-off between  a
design  that allows  reuse  without compromising  encapsulation and  a
design   that    clearly   compromises   encapsulation    and,   thus,
maintainabilty.

Origin: a clone of inf319git/queueiStack [2023/09].
